from tkinter import*
import random
import time
import datetime
from tkinter import simpledialog
from tkinter import Tk, StringVar, ttk
from tkinter import messagebox
import tkinter as tk


root = Tk()
ws = Tk()
ws.title('Account Registration')
root.geometry("600x800+0+0")
root.title("Bake Your Cake")


# Start New Window
window = tk.Toplevel(root)  # create new window object
window.title("Account Registration")  # set title of the window
window.geometry('400x300+900+0')

# create variables
fname = StringVar(value='')
lname = StringVar(value='')
address = StringVar(value='')

fname_label = Label(window, text='First Name: ', font=("Arial", 16))
fname_label.grid(row=2, column=1, pady=20)
fname_entry = Entry(window, textvariable=fname, width=15)
fname_entry.grid(row=2, column=2, ipadx=60, ipady=4)


lname_label = Label(window, text='Last Name: ', font=("Arial", 16))
lname_label.grid(row=3, column=1, pady=20)
lname_entry = Entry(window, textvariable=lname, width=15)
lname_entry.grid(row=3, column=2, ipadx=60, ipady=4)

address_label = Label(window, text='Address: ', font=("Arial", 16))
address_label.grid(row=4, column=1, pady=20)
address_entry = Entry(window, textvariable=address, width=15)
address_entry.grid(row=4, column=2, ipadx=60, ipady=4)


def Continue():
    return messagebox.showinfo('Account Registration', 'Account created successfully!')


Button(ws, text="Continue", command="continue").pack(pady=20)
# End New Window


Tops = Frame(root, width=1000, height=100, bd=10, relief="raise")

Tops.pack(side=TOP)

lblTitle = Label(Tops, font=('arial', 30, 'bold', 'italic'),

                 text="   Bake Your Cake   ")

lblTitle.grid(row=0, column=0)


BottomMainFrame = Frame(root, width=1000, height=950, bd=10, relief="raise")

BottomMainFrame.pack(side="bottom")


f1 = Frame(BottomMainFrame, width=400, height=1000, bd=10, relief="raise")

f1.pack(side=LEFT)

# inserting first image of cake
photo = tk.PhotoImage(file="cake.jpg")

frame = ttk.Frame(root, relief=tk.RAISED)
frame.grid(row=0, column=0, sticky=tk.NSEW)
label = tk.Label(
    frame, image=photo, compound=tk.CENTER,
    font="Helvetica 40 bold",
    foreground="yellow", text="Welcome")
label.grid(row=0, column=0, sticky=tk.NSEW)


f2TOP = Frame(BottomMainFrame, width=600, height=600, bd=10, relief="raise")

f2TOP.pack(side=TOP)

# inserting second image of cake
photo = tk.PhotoImage(file="cake.jpg")

f2BOTTOM = Frame(BottomMainFrame, width=600, height=400, bd=10, relief="raise")

f2BOTTOM.pack(side=BOTTOM)


def write_slogan():
    print("Tkinter is easy to use!")


root = tk.Tk()
frame = tk.Frame(root)
frame.pack()

slogan = tk.Button(frame,
                   text="Continue",
                   command=write_slogan)
slogan.pack(side=tk.LEFT)

button = tk.Button(frame,
                   text="QUIT",
                   fg="red",
                   command=quit)
button.pack(side=tk.LEFT)


def myfunction(event):
    print button[event.widget]


buttons = {}
for i in range(10):
    b = tk.Button(root, text='button' + str(i))
    buttons[b] = i  # save button, index as key-value pair
    b.bind("<Button-1>", myfunction)
    b.place(x=10, y=(10+(25*i)))

root.mainloop()
